Group Members: Group 3.

ID:	    Name:	                Section:

21772	ABDUL REHMAN ABBASI	    50382
21604	AIZA KHAN	            50382
22771	SYED DANIAL ALI	NAQVI       50382
22811	MIRZA BILAL BAIG	    50383
22850	USMAN GHANI BAWANI	    50383



GAME CONTENTS:
* A main menu is displayed when the game starts.
* A new Level 1 is generated when "New" is pressed on the main menu.
* The game is laoded from the same level where it was paused, when "Load" is pressed   on the main menu.
* The game Exits, when "Quit" is pressed on the main menu.
* Game has 2 levels.
* User can pause the game by pressing "Escape" key.
* Level 1 is generated each time "New" is pressed.
* Random Level Bricks are generated in a structurized pattern.
* Bricks are destroyed through collision according to its Brick level.
* A random power up is generated after an interval upon breaking the brick.
* Powerups such as fireball and bullet power up lasts only for a while and then paddle returns to normal.
* The paddle needs to catch the power up, to gain a super power.
* When all the Bricks on level 1 are destroyed, level 1 is completed.
* When level 1 is completed Level 2 is loaded, with a Dailogue box, congratulating the   user.
* On level 2, Random level bricks are loaded in a heart shape.
* When Level 2 is completed, user has won. Winner screen is displayed.
* If lifes end, Game over. User can restart the game by pressing "Enter key".





INDIVIAL TASKS:

Mirza Bilal Baig (ERP = 22811):

- Completed Task 3. 
- Integrated power up code to the main(Gameplay) code.
- Implemented paddle and its functions in Gameplay code.
- Implemented ball class in Gameplay.
- Made Split ball power up class.
- Made Ball class.

Aiza Khan (ERP = 21604)

- Completed Task 1.

Usman Ghani Bawany (ERP = 22850):

- Completed Task 4.
- Created Menu Class.

Syed Daniyal Ali Naqvi (ERP = 22771):

- Completed Task 5. 
- Helped in displaying scores and lifes on screen.
- Helped in writing game restart code when "Enter key pressed".

Abdul Rehman Abbasi (ERP 21772):

- Completed task 2. 
- Assembled the whole code.
- Created BackGround for Menu, Levels, and Winner.
- Integrated the Bricks Code to the GamePlay class.
- Created collision functions.
- Created winner function and Restart on key press in gamepaly class
- Added code for keyListeners and mouse listener.
- Created GamePlay Class.
.


